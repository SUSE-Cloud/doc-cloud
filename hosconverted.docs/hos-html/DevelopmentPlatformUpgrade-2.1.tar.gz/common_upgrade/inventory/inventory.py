#!/usr/bin/env python
#
# Copyright (c) 2014 Hewlett-Packard Development Company, L.P.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.
# See the License for the specific language governing permissions and
# limitations under the License.

DOCUMENTATION = '''
---
inventory: nova
short_description: Nova external inventory script
description:
    - Generates inventory that Ansible can understand by making API requests to
      Nova API
requirements: [ "novaclient" , "keystoneclient" ]
'''

import json
import os
import re
import sys

from oslo_config import cfg

dev_platform_services = ['trove']

opts = [
    cfg.BoolOpt('list', help='List active hosts'),
    cfg.StrOpt('username'),
    cfg.StrOpt('password'),
    cfg.StrOpt('auth-url'),
    cfg.StrOpt('project-id'),
    cfg.StrOpt('cacert'),
    cfg.StrOpt('group-regex'),
]

try:
    from novaclient.v1_1 import client as nova_client
except ImportError:
    print('novaclient is required')
    sys.exit(1)

try:
    from keystoneclient.v3 import client as keystone_client
except ImportError:
    print('keystoneclient is required')
    sys.exit(1)


def _parse_config():
    configs = cfg.ConfigOpts()
    configs.register_cli_opts(opts)
    configs(prog='ansible-inventory')
    if configs.auth_url is None:
        if "OS_AUTH_URL" in os.environ:
            configs.auth_url = os.environ.get('OS_AUTH_URL')
    if configs.username is None:
        if "OS_USERNAME" in os.environ:
            configs.username = os.environ.get('OS_USERNAME')
    if configs.password is None:
        if "OS_PASSWORD" in os.environ:
            configs.password = os.environ.get('OS_PASSWORD')
    if configs.project_id is None:
        if "OS_TENANT_NAME" in os.environ:
            configs.project_id = os.environ.get('OS_TENANT_NAME')
        elif "OS_PROJECT_NAME" in os.environ:
            configs.project_id = os.environ.get('OS_PROJECT_NAME')
    if configs.cacert is None:
        if "OS_CACERT" in os.environ:
            configs.cacert = os.environ.get('OS_CACERT')
    if '/v2.0' in configs.auth_url:
        configs.auth_url = configs.auth_url.replace('/v2.0', '/v3')
    return configs


def _get_dev_platform_instance_ip(server):
    if 'SVC' in server.addresses:
        return server.addresses['SVC'][0]['addr']
    else:
        for network in server.addresses:
            for port in server.addresses[network]:
                if port['OS-EXT-IPS:type'] == 'floating':
                    return port['addr']


class AnsibleInventory(object):
    def __init__(self, configs):
        self.configs = configs
        self._ksclient = None
        self._nclient = None

    def list(self):
        hostvars = {}
        groups = {}
        # XXX: need to config access details
        for res in self.nclient.servers.list():
          try:
              server = self.nclient.servers.get(res.id)
              private = [
                  x['addr'] for x in getattr(
                      server,
                      'addresses'
                  ).itervalues().next()
                  if x['OS-EXT-IPS:type'] == 'fixed'
              ]
              if private:
                  private = private[0]
              public = [
                  x['addr'] for x in getattr(
                      server,
                      'addresses'
                  ).itervalues().next()
                  if x['OS-EXT-IPS:type'] == 'floating']

              if public:
                  public = public[0]

              if any(x in server.name for x in dev_platform_services):
                  addr = _get_dev_platform_instance_ip(server)
              else:
                  addr = server.accessIPv4 or public or private

              groups[res.id] = [addr]
              groups[server.name] = [addr]
              if self.configs.group_regex:
                  group_name = re.search(
                      self.configs.group_regex, res.name
                  )
                  if group_name:
                      group_name = group_name.group(0)
                      if group_name in groups:
                          groups[group_name].append(addr)
                      else:
                          groups[group_name] = [addr]
              if 'group' in server.metadata:
                  group_name = server.metadata['group']
                  if group_name in groups:
                      groups[group_name].append(addr)
                  else:
                      groups[group_name] = [addr]

                  prefixed_group_name = "trove-%s" % (group_name)
                  if prefixed_group_name in groups:
                      groups[prefixed_group_name].append(addr)
                  else:
                      groups[prefixed_group_name] = [addr]

              hostvars[addr] = {}
              hostvars[addr]['instance_status'] = server.status
              hostvars[addr]['instance_image_id'] = server.image['id']
              hostvars[addr]['instance_name'] = server.name
              hostvars[addr]['instance_id'] = res.id

          except Exception as e:
              pass

        inventory = {'_meta': {'hostvars': hostvars}}
        inventory.update(groups)
        print(json.dumps(inventory, indent=2))

    @property
    def ksclient(self):
        if self._ksclient is None:
            self._ksclient = keystone_client.Client(
                auth_url=self.configs.auth_url,
                username=self.configs.username,
                password=self.configs.password,
                cacert=self.configs.cacert,
                project_name=self.configs.project_id)
            self._ksclient.authenticate()
        return self._ksclient

    @property
    def nclient(self):
        if self._nclient is None:
            ksclient = self.ksclient
            endpoint = ksclient.service_catalog.url_for(
                service_type='compute', endpoint_type='publicURL')
            self._nclient = nova_client.Client(
                bypass_url=endpoint,
                username=None,
                api_key=None,
                project_id=self.configs.project_id,
                auth_url=self.configs.auth_url,
                cacert=self.configs.cacert,
                auth_token=ksclient.auth_token)
        return self._nclient


def main():
    configs = _parse_config()
    hi = AnsibleInventory(configs)
    if configs.list:
        hi.list()
    sys.exit(0)

if __name__ == '__main__':
    main()
