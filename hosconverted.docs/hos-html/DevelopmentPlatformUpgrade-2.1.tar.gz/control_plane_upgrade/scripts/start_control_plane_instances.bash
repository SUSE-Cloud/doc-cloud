#!/bin/bash
# Copyright (c) 2014 Hewlett-Packard Development Company, L.P.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# Example

#This will reboot all the instances for dev platform services, both control plane and customer instances.

#It gets the list of images from glance matching dev platform image name patterns and then
#get list of instances running with those image_id and starts/reboot such instances

openstack role list | grep admin > /dev/null
if [ $? -ne 0 ]; then
    echo "Error: Please run the script after sourcing nova admin credentials"
    exit 1
fi

for instance_id in $(nova list --all-tenants | awk '{print $2}' | grep -v ID); do

    instance_name=$(nova show $instance_id | grep " name " | awk '{print $4}')
    if [ $instance_name = "hot_pool" ];
    then
        echo "starting ihot_pool instance $instance_id"
        nova start $instance_id

        #lets just give some time for nova and not overload it with stop requests
        sleep 5
    fi
done


for instance_name in $(nova list --all-tenants | grep trove- | grep SVC= | grep trove_mgmt_network= | awk '{print $4}' ); do
    echo "starting $instance_name"
    nova start $instance_name

    #lets just give some time for nova and not overload it with reboot requests
    sleep 5
done
