STOP-START INSTRUCTIONS

Before upgrading Helion Openstack 2.0 to 2.1, it is necessary to safely stop all databases and the database service. After the upgrade happens it is then necessary to safely restart all of the databases and services. 

1. Download the following file that contains the upgrade scripts.
	Tip: The easiest option is to download directly to the physical machine hosting the HPE Helion OpenStack lifecycle manager. If you can not download directly to that location, download the files to portable storage media and then copy the files onto the lifecycle manager. When downloading or copying, make sure there is enough space; the file sizes can be significant.

2. SSH to the HPE Helion OpenStack lifecycle manager (previously known as the deployer node).

3. Untar the DevelopmentPlatformUpgrade-2.1.tar.gz file to a local temp directory
	tar -xzf DevelopmentPlatformUpgrade-2.1.tar.gz

4. Source a virtual environment containing the Openstack clients. We recommend using the built in virtual environment on the HPE Helion OpenStack lifecycle manager.
	source /opt/stack/venv/openstackclient-<timestamp>/bin/activate

5. Execute the following command to source credentials with access to the service.
	source service.osrc

6. Disable Access to the Trove API to stop all activity
	ansible-playbook --private-key <path to SSH private key> -i ./common_upgrade/inventory/inventory.py ./control_plane_upgrade/playbooks/stop-api.yml
	Tip: The SSH private key file is the one specified during creation of the database service. In most installation the same key will be used for all commands in this guide.

7. Safely stop all guest databases
	ansible-playbook --extra-vars guest_private_key_file=<path to SSH private key> --private-key <path to SSH private key> -i ./common_upgrade/inventory/inventory.py ./guest-upgrade/playbooks/stop-guests.yml

8. Safely stop the trove services
	ansible-playbook --private-key <path to SSH private key> -i ./common_upgrade/inventory/inventory.py ./control_plane_upgrade/playbooks/control_plane_stop.yml

9.  Stop all control plane instances
	./control_plane_upgrade/scripts/stop_control_plane_instances.bash

---------- RUN HELION OPENSTACK 2.1 UPGRADE HERE ---------

10. Restart all control plane instances
	./control_plane_upgrade/scripts/start_control_plane_instances.bash

11. Safely start the trove services
	ansible-playbook --private-key <path to SSH private key> -i ./common_upgrade/inventory/inventory.py ./control_plane_upgrade/playbooks/control_plane_start.yml

12. Start all databases intances
	ansible-playbook --extra-vars guest_private_key_file=<path to SSH private key> --private-key <path to SSH private key> -i ./common_upgrade/inventory/inventory.py ./guest-upgrade/playbooks/start-guests.yml

13. Verify all guest instances were restarted successfully.
	cat ~/guest-instance-status.log

14. Restart the Database API service. After this step the database serice will be fully functional
	ansible-playbook --private-key <path to SSH private key> -i ./common_upgrade/inventory/inventory.py ./control_plane_upgrade/playbooks/start-api.yml